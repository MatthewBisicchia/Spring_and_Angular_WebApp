package com.matthewbisicchia.programmingChallenges;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgrammingChallengesApplicationTests {

	@Test
	void contextLoads() {
	}

}
